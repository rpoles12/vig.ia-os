7SET.DEV - EXPLORACAO DE IDENTIDADE NEON

CONTEUDO
01-terminal-principal.png
Interface principal com olho digital, memoria e cronologia.

02-grades-e-texturas.png
Prancha com grade em perspectiva, dither, interferencia e quadros fragmentados.

03-cartaz-neon.png
Cartaz vertical para divulgacao escolar com a tecla aprovada.

04-tela-evidencias.png
Interface de investigacao, acessos, arquivos, audio e cronologia.

05-aplicacoes-identidade.png
Prancha com cartaz, pasta, cracha, terminal, cartoes e itens fisicos.

06-wordmark-neon.svg
Versao luminosa para telas, chamadas e cartazes. Nao substitui as versoes
planas em impressoes pequenas, documentos oficiais ou fundos complexos.

REGRA DO BRILHO
O nucleo branco/lilas precisa continuar nitido. O brilho roxo deve ocupar
aproximadamente de 8% a 18% da altura das letras ou bordas. Informacoes
essenciais, horarios, nomes e instrucoes nao recebem desfoque.

OBSERVACAO
As imagens sao direcoes conceituais. Textos pequenos devem ser redesenhados
na arte final para garantir ortografia, acessibilidade e dados corretos.
