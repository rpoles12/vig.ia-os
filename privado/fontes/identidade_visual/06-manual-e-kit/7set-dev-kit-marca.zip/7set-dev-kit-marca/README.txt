KIT DE MARCA 7SET.DEV

LOGO OFICIAL
O logo e exclusivamente tipografico: 7set.dev em Space Grotesk Bold.
Nao anexar o olho, a tecla ou outros simbolos ao wordmark.

ARQUIVOS
- 7set-dev-wordmark-roxo.svg: uso principal.
- 7set-dev-wordmark-claro.svg: fundos pretos ou fotografias escuras.
- 7set-dev-wordmark-preto.svg: fundos claros e impressao simples.
- PNGs equivalentes: uso rapido em apresentacoes e cartazes.
- 7set-dev-tecla-olho.png: imagem principal da campanha; nao e logo.
- brand-tokens.json: cores, fontes e regras em formato estruturado.
- fonts/: fontes utilizadas e respectivas licencas.

REGRA PRINCIPAL
Em materiais institucionais, o wordmark identifica a marca. A tecla com olho
cria atmosfera e funciona como imagem de campanha.

CORES
Preto #08070C
Preto-violeta #14111C
Ultravioleta #6426C9
Roxo neon #A66BFF
Lilas claro #E8DCFF
Cinza tecnico #9B96A5

TIPOGRAFIA
Space Grotesk Bold: logo, titulos e chamadas.
IBM Plex Mono Regular: codigos, horarios, logs, etiquetas e dados.

USO EM CARTAZ
Fundo preto, tecla grande, wordmark separado, titulo curto, dados em blocos.
Aplicar glitches apenas em imagens decorativas; nunca em informacoes essenciais.
